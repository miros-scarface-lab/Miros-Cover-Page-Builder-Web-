import { getStore } from "@netlify/blobs";

const visitsFile = "visits.txt";
const visitStore = getStore("miros-cover-page-usage");

export default async (request) => {
  if (request.method !== "GET" && request.method !== "POST") {
    return Response.json(
      { error: "Method not allowed" },
      { status: 405, headers: { Allow: "GET, POST" } },
    );
  }

  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    if (request.method === "GET") {
      const entry = await visitStore.getWithMetadata(visitsFile, {
        type: "text",
        consistency: "strong",
      });
      const count = parseCount(entry?.data ?? "0");
      return count === null
        ? errorResponse("Visit count is invalid", 500)
        : countResponse(count);
    }

    for (let attempt = 0; attempt < 8; attempt++) {
      const entry = await visitStore.getWithMetadata(visitsFile, {
        type: "text",
        consistency: "strong",
      });
      const currentCount = parseCount(entry?.data ?? "0");
      if (currentCount === null || currentCount === Number.MAX_SAFE_INTEGER)
        return errorResponse("Visit count is invalid", 500);

      const nextCount = currentCount + 1;
      const writeOptions = entry
        ? { onlyIfMatch: entry.etag }
        : { onlyIfNew: true };
      const write = await visitStore.set(
        visitsFile,
        String(nextCount),
        writeOptions,
      );
      if (write.modified) return countResponse(nextCount);
    }

    return errorResponse("Visit count is busy; please retry", 503);
  } catch {
    return errorResponse("Visit count is temporarily unavailable", 503);
  }
};

export const config = { path: "/api/usage-count" };

function parseCount(value) {
  const count = Number(String(value).trim() || "0");
  return Number.isSafeInteger(count) && count >= 0 ? count : null;
}

function countResponse(count) {
  return Response.json({ count }, { headers: { "Cache-Control": "no-store" } });
}

function errorResponse(message, status) {
  return Response.json(
    { error: message },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}
