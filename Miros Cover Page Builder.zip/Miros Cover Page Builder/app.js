(() => {
  "use strict";

  const university = "Pirojpur Science and Technology University";
  const departments = [
    "Computer Science & Engineering",
    "Mathematics",
    "Psychology",
    "Statistics",
  ];
  const documentTypes = [
    "Assignment",
    "Lab Report",
    "Assignment/Lab-Report",
    "Project Report",
  ];
  const faculties = {
    "Computer Science & Engineering": {
      color: "#2563eb",
      teachers: [
        ["Dr. Shohag Barman", "Assistant Professor & Chairman"],
        ["K. M. Aslam Uddin", "Assistant Professor"],
        ["Abdullah Al Zubaer", "Lecturer"],
        ["Md. Shamim Imtiaz", "Lecturer"],
      ],
    },
    Mathematics: {
      color: "#059669",
      teachers: [
        ["Dr. Md. Mosharrof Hossain", "Associate Professor & Chairman"],
        ["Dr. Akter Hossain", "Associate Professor"],
        ["Rubina Begum Tanjila", "Lecturer"],
      ],
    },
    Psychology: {
      color: "#d97706",
      teachers: [
        ["Sharmin Islam Nipa", "Lecturer & Chairman"],
        ["Najma Akter", "Lecturer"],
        ["Reya Raihan", "Lecturer"],
        ["Ovijit Roy", "Lecturer"],
      ],
    },
    Statistics: {
      color: "#7c3aed",
      teachers: [
        ["Dr. Md. Musa Khan", "Associate Professor & Chairman"],
        ["Rehana Akter Tamim", "Lecturer"],
        ["Sumaya Sultana", "Lecturer"],
        ["Md. Maeen Molla", "Lecturer"],
      ],
    },
  };
  const designations = [
    ...new Set([
      "Professor",
      "Associate Professor",
      "Assistant Professor",
      "Lecturer",
      "Instructor",
      "Teaching Assistant",
      ...Object.values(faculties).flatMap(({ teachers }) =>
        teachers.map(([, designation]) => designation),
      ),
    ]),
  ];
  const themeColors = {
    "#2563eb": "Royal Blue",
    "#059669": "Emerald Green",
    "#7c3aed": "Deep Purple",
    "#d97706": "Amber Gold",
    "#dc2626": "Crimson Red",
  };
  const form = document.querySelector("#cover-form");
  const preview = document.querySelector("#cover-preview");
  const teachersList = document.querySelector("#teachers-list");
  const includeDateToggle = document.querySelector("#include-submission-date");
  const submissionDateInput = document.querySelector("#submission-date");
  const showBoxOutlinesToggle = document.querySelector("#show-box-outlines");
  const toast = document.querySelector(".toast");
  const menu = document.querySelector(".menu-wrap");
  const usageCountLabel = document.querySelector("#usage-count");
  const activity = [];
  let teacherId = 1;
  let currentTheme = "#2563eb";
  let currentFont = "serif";
  let toastTimer;

  const getField = (name) => form.elements.namedItem(name);
  const getValue = (name) => getField(name).value.trim();

  function logAction(message) {
    activity.unshift({ message, time: new Date() });
    activity.splice(30);
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(
      () => toast.classList.remove("visible"),
      2600,
    );
  }

  function setPreviewValue(name, value, fallback = "") {
    const element = preview.querySelector(`[data-preview="${name}"]`);
    element.textContent = value || fallback;
    element.hidden = !value && !fallback;
  }

  function currentDateValue() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${now.getFullYear()}-${month}-${day}`;
  }

  function formatSubmissionDate(value) {
    if (!value) return "";
    const [year, month, day] = value.split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString(undefined, {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  }

  async function updateUsageCount() {
    if (!/^https?:$/.test(window.location.protocol)) {
      usageCountLabel.textContent = "Visit count appears when hosted";
      return;
    }

    try {
      const response = await fetch("/api/usage-count", {
        method: "POST",
        headers: { Accept: "application/json" },
      });
      if (!response.ok) throw new Error("Counter service unavailable");

      const { count } = await response.json();
      if (!Number.isSafeInteger(count) || count < 0)
        throw new Error("Invalid counter response");

      usageCountLabel.textContent = `${count.toLocaleString()} visits so far`;
    } catch {
      usageCountLabel.textContent = "Visit count temporarily unavailable";
    }
  }

  function selectedDepartment() {
    return getValue("teacherDepartment") || getValue("department");
  }

  function renderDepartmentChips(container, input, syncAll = false) {
    const row = document.querySelector(container);
    row.replaceChildren();
    departments.forEach((department) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = `chip${input.value.trim().toLowerCase() === department.toLowerCase() ? " active" : ""}`;
      chip.textContent = department;
      chip.addEventListener("click", () => {
        input.value = department;
        if (syncAll) {
          getField("studentDepartment").value = department;
          getField("teacherDepartment").value = department;
        }
        render();
      });
      row.append(chip);
    });
  }

  function renderDocTypeChips() {
    const row = document.querySelector(".document-chips");
    row.replaceChildren();
    documentTypes.forEach((type) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = `chip${getValue("documentType").toLowerCase() === type.toLowerCase() ? " active" : ""}`;
      chip.textContent = type;
      chip.addEventListener("click", () => {
        getField("documentType").value = type;
        render();
      });
      row.append(chip);
    });
  }

  function addTeacher(name = "", designation = "") {
    if (teachersList.children.length >= 3) {
      showToast("A maximum of 3 teachers fits on the A4 cover.");
      return;
    }
    const index = teacherId++;
    const card = document.createElement("div");
    card.className = "teacher-card";
    card.dataset.teacher = String(index);
    card.innerHTML = `
      <div class="teacher-card-head"><span>Teacher ${teachersList.children.length + 1}</span>
        <button type="button" class="remove-teacher" aria-label="Remove teacher ${teachersList.children.length + 1}">×</button>
      </div>
      <label class="field-label" for="teacher-name-${index}">Name</label>
      <input id="teacher-name-${index}" name="teacherName${index}" placeholder="Course instructor">
      <div class="faculty-block"></div>
      <label class="field-label" for="teacher-designation-${index}">Designation</label>
      <input id="teacher-designation-${index}" name="teacherDesignation${index}" placeholder="Course instructor designation">
      <div class="chip-row designation-chips" aria-label="Designation suggestions"></div>`;
    card.querySelector(`[name="teacherName${index}"]`).value = name;
    card.querySelector(`[name="teacherDesignation${index}"]`).value =
      designation;
    card.querySelector(".remove-teacher").addEventListener("click", () => {
      if (teachersList.children.length <= 1) {
        showToast("At least one teacher is required.");
        return;
      }
      card.remove();
      renumberTeachers();
      render();
    });
    teachersList.append(card);
    updateTeacherControls();
    renderFacultyChips(card);
    if (teachersList.children.length > 1) logAction("Added a teacher");
    render();
  }

  function renumberTeachers() {
    [...teachersList.children].forEach((card, index) => {
      const title = card.querySelector(".teacher-card-head span");
      const button = card.querySelector(".remove-teacher");
      title.textContent = `Teacher ${index + 1}`;
      button.setAttribute("aria-label", `Remove teacher ${index + 1}`);
    });
    updateTeacherControls();
  }

  function updateTeacherControls() {
    const addButton = document.querySelector("#add-teacher");
    addButton.disabled = teachersList.children.length >= 3;
    addButton.title = addButton.disabled
      ? "A maximum of 3 teachers fits on the A4 cover."
      : "";
  }

  function renderFacultyChips(card) {
    const block = card.querySelector(".faculty-block");
    block.replaceChildren();
    const selected = selectedDepartment().toLowerCase();
    const matches = Object.entries(faculties).filter(
      ([department]) =>
        selected.includes(department.toLowerCase()) ||
        (department.startsWith("Computer") && selected.includes("cse")),
    );
    const groups = matches.length ? matches : Object.entries(faculties);
    groups.forEach(([department, faculty]) => {
      const group = document.createElement("div");
      group.className = "faculty-group";
      group.innerHTML = `<p class="faculty-heading"></p><div class="chip-row"></div>`;
      group.querySelector(".faculty-heading").textContent =
        `${department.split(" ")[0] === "Computer" ? "CSE" : department} Faculty`;
      const row = group.querySelector(".chip-row");
      faculty.teachers.forEach(([name, designation]) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "chip faculty-chip";
        chip.style.setProperty("--faculty-color", faculty.color);
        chip.textContent = name;
        chip.classList.toggle(
          "active",
          card.querySelector('[name^="teacherName"]').value.trim() === name,
        );
        chip.addEventListener("click", () => {
          card.querySelector('[name^="teacherName"]').value = name;
          card.querySelector('[name^="teacherDesignation"]').value =
            designation;
          getField("teacherDepartment").value = department;
          render();
        });
        row.append(chip);
      });
      block.append(group);
    });
  }

  function renderDesignationChips(card) {
    const row = card.querySelector(".designation-chips");
    const input = card.querySelector('[name^="teacherDesignation"]');
    row.replaceChildren();
    designations.forEach((designation) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = `chip${input.value.trim().toLowerCase() === designation.toLowerCase() ? " active" : ""}`;
      chip.textContent = designation;
      chip.addEventListener("click", () => {
        input.value = designation;
        render();
      });
      row.append(chip);
    });
  }

  function renderTeacherPreview() {
    const container = preview.querySelector(".preview-teachers");
    container.replaceChildren();
    [...teachersList.children].forEach((card) => {
      const name = card.querySelector('[name^="teacherName"]').value.trim();
      const designation = card
        .querySelector('[name^="teacherDesignation"]')
        .value.trim();
      if (!name && !designation) return;
      const entry = document.createElement("div");
      entry.className = "preview-teacher";
      if (name) {
        const strong = document.createElement("strong");
        strong.textContent = name;
        entry.append(strong);
      }
      if (designation) {
        const span = document.createElement("span");
        span.textContent = designation;
        entry.append(span);
      }
      container.append(entry);
    });
  }

  function render() {
    const values = {
      department: getValue("department"),
      documentType: getValue("documentType"),
      courseTitle: getValue("courseTitle"),
      courseCode: getValue("courseCode"),
      studentName: getValue("studentName"),
      studentId: getValue("studentId"),
      studentSession: getValue("studentSession"),
      studentDepartment: getValue("studentDepartment"),
      studentUniversity: getValue("studentUniversity"),
      teacherDepartment: getValue("teacherDepartment"),
      teacherUniversity: getValue("teacherUniversity"),
    };
    setPreviewValue("studentUniversity", values.studentUniversity, university);
    setPreviewValue(
      "department",
      values.department,
      ".............................................",
    );
    for (const [key, value] of Object.entries(values)) {
      if (key !== "studentUniversity" && key !== "department")
        setPreviewValue(key, value);
    }
    renderTeacherPreview();
    const includeDate = includeDateToggle.checked;
    const dateBox = preview.querySelector(".submission-date-box");
    dateBox.hidden = !includeDate;
    preview.classList.toggle("with-submission-date", includeDate);
    preview.classList.toggle(
      "box-outlines-hidden",
      !showBoxOutlinesToggle.checked,
    );
    document.querySelector("#submission-date-field").hidden = !includeDate;
    document.querySelector("#preview-submission-date").textContent =
      formatSubmissionDate(submissionDateInput.value);
    renderDepartmentChips(".department-chips", getField("department"), true);
    renderDepartmentChips(
      ".student-department-chips",
      getField("studentDepartment"),
    );
    renderDepartmentChips(
      ".teacher-department-chips",
      getField("teacherDepartment"),
    );
    renderDocTypeChips();
    [...teachersList.children].forEach((card) => {
      renderFacultyChips(card);
      renderDesignationChips(card);
    });
    document.documentElement.style.setProperty(
      "--paper-font",
      fontStack(currentFont),
    );
  }

  function fontStack(font) {
    if (font === "sans-serif") return "Arial, Helvetica, sans-serif";
    if (font === "monospace") return '"Courier New", Courier, monospace';
    if (font === "cursive")
      return '"Comic Sans MS", "Brush Script MT", cursive';
    return 'Georgia, "Times New Roman", serif';
  }

  function applyTheme(color) {
    currentTheme = color;
    document.documentElement.style.setProperty("--accent", color);
    const channels = color
      .match(/[0-9a-f]{2}/gi)
      .map((hex) => parseInt(hex, 16));
    document.documentElement.style.setProperty(
      "--accent-rgb",
      channels.join(", "),
    );
    document.querySelectorAll("[data-theme]").forEach((button) => {
      button.querySelector("span").textContent =
        button.dataset.theme === currentTheme ? "✓" : "";
    });
  }

  function renderFontSelection() {
    document.querySelectorAll("[data-font]").forEach((button) => {
      button.classList.toggle("selected", button.dataset.font === currentFont);
    });
  }

  function fillSampleData() {
    const sample = {
      department: "Computer Science & Engineering",
      documentType: "Lab Report",
      courseTitle: "Data Structures and Algorithms",
      courseCode: "CSE-2101",
      studentName: "Miros",
      studentId: "2021-01-042",
      studentSession: "2022-2023",
      studentDepartment: "Computer Science & Engineering",
      studentUniversity: university,
      teacherDepartment: "Computer Science & Engineering",
      teacherUniversity: university,
    };
    Object.entries(sample).forEach(([key, value]) => {
      getField(key).value = value;
    });
    teachersList.replaceChildren();
    teacherId = 0;
    addTeacher("Dr. Strange", "Professor");
    addTeacher("Tony Stark", "Professor");
    logAction("Filled sample data");
    render();
    showToast("Sample cover page is ready.");
  }

  function clearForm() {
    form.reset();
    Object.entries({
      studentUniversity: university,
      teacherUniversity: university,
    }).forEach(([key, value]) => {
      getField(key).value = value;
    });
    teachersList.replaceChildren();
    teacherId = 0;
    addTeacher("Course Instructor", "Course Instructor Designation");
    getField("documentType").value = "Assignment/Lab-Report";
    logAction("Cleared form data");
    render();
    showToast("Form cleared. Start with your document details.");
  }

  function safeFilename(extension) {
    const title = getValue("courseTitle") || "Cover Page";
    const safeTitle =
      title
        .replace(/[\\/:*?"<>|]/g, "")
        .replace(/\s+/g, " ")
        .trim() || "Cover Page";
    return `${safeTitle} by miros.${extension}`;
  }

  function drawWrappedText(
    ctx,
    value,
    x,
    y,
    maxWidth,
    lineHeight,
    align = "left",
  ) {
    const words = String(value).split(/\s+/).filter(Boolean);
    const lines = [];
    let currentLine = "";
    for (const word of words) {
      let remaining = word;
      while (
        remaining &&
        ctx.measureText(currentLine ? `${currentLine} ${remaining}` : remaining)
          .width > maxWidth
      ) {
        if (currentLine) {
          lines.push(currentLine);
          currentLine = "";
        } else {
          let split = 1;
          while (
            split < remaining.length &&
            ctx.measureText(remaining.slice(0, split + 1)).width <= maxWidth
          )
            split++;
          lines.push(remaining.slice(0, split));
          remaining = remaining.slice(split);
        }
      }
      if (remaining)
        currentLine = currentLine ? `${currentLine} ${remaining}` : remaining;
    }
    if (currentLine) lines.push(currentLine);
    ctx.textAlign = align;
    lines.forEach((line, index) =>
      ctx.fillText(line, x, y + index * lineHeight, maxWidth),
    );
    return lines.length;
  }

  function drawBox(ctx, x, y, width, height, radius = 5) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height - r);
    ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    ctx.lineTo(x + r, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.stroke();
  }

  function makeExportCanvas(logo) {
    const width = 2480;
    const height = Math.round((width * 297) / 210);
    const scale = width / 793.7;
    const mm = (value) => (value * width) / 210;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx)
      throw new Error("Your browser could not prepare the A4 document.");

    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#111";
    ctx.strokeStyle = "#141414";
    ctx.lineWidth = 1.2 * scale;
    ctx.textBaseline = "alphabetic";
    const font = fontStack(currentFont);
    const fontStyle = (size, weight = 400) =>
      `${weight} ${size * scale}px ${font}`;
    const pageMargin = mm(25.4);
    const contentX = pageMargin;
    const contentWidth = width - pageMargin * 2;
    const centerX = width / 2;
    const headerY = mm(13.9);
    const courseY = mm(117);
    const courseHeight = mm(42);
    const submissionY = mm(163);
    const includeDate = includeDateToggle.checked;
    const showBoxOutlines = showBoxOutlinesToggle.checked;
    const dateBoxHeight = mm(13);
    const dateBoxGap = mm(4);
    const submissionHeight =
      height -
      mm(25.4) -
      submissionY -
      (includeDate ? dateBoxHeight + dateBoxGap : 0);
    const dateBoxY = height - mm(25.4) - dateBoxHeight;
    const boxGap = mm(4);
    const boxWidth = (contentWidth - boxGap) / 2;
    const leftX = contentX;
    const rightX = contentX + boxWidth + boxGap;
    const paperText = (
      value,
      x,
      y,
      maxWidth,
      size,
      weight = 400,
      lineHeight = size * 1.3,
      align = "left",
    ) => {
      ctx.font = fontStyle(size, weight);
      ctx.fillStyle = "#111";
      return drawWrappedText(
        ctx,
        value,
        x,
        y,
        maxWidth,
        lineHeight * scale,
        align,
      );
    };

    paperText(
      getValue("studentUniversity") || university,
      centerX,
      headerY + mm(16),
      contentWidth,
      24,
      700,
      29,
      "center",
    );
    const logoSize = mm(56);
    ctx.drawImage(
      logo,
      centerX - logoSize / 2,
      headerY + mm(26),
      logoSize,
      logoSize,
    );
    paperText(
      `Department of ${getValue("department") || "............................................."}`,
      centerX,
      headerY + mm(94),
      contentWidth,
      18,
      600,
      19,
      "center",
    );

    if (showBoxOutlines)
      drawBox(ctx, contentX, courseY, contentWidth, courseHeight, 5 * scale);
    const coursePadding = mm(6);
    const courseTextX = contentX + coursePadding;
    const courseTextWidth = contentWidth - coursePadding * 2;
    const docType = getValue("documentType");
    if (docType) {
      ctx.font = fontStyle(18, 700);
      ctx.textAlign = "center";
      ctx.fillText(docType, centerX, courseY + mm(9), courseTextWidth);
      const docWidth = Math.min(
        ctx.measureText(docType).width,
        courseTextWidth,
      );
      ctx.beginPath();
      ctx.moveTo(centerX - docWidth / 2, courseY + mm(9.7));
      ctx.lineTo(centerX + docWidth / 2, courseY + mm(9.7));
      ctx.stroke();
    }
    const labelWidth = mm(31);
    const courseValueWidth = courseTextWidth - labelWidth - mm(2);
    const drawCourseLine = (label, value, y) => {
      ctx.font = fontStyle(12, 600);
      ctx.textAlign = "left";
      ctx.fillText(label, courseTextX, y);
      paperText(
        value,
        courseTextX + labelWidth,
        y,
        courseValueWidth,
        12,
        400,
        15,
      );
    };
    drawCourseLine("Course Title:", getValue("courseTitle"), courseY + mm(25));
    drawCourseLine("Course Code:", getValue("courseCode"), courseY + mm(36));

    if (showBoxOutlines) {
      drawBox(ctx, leftX, submissionY, boxWidth, submissionHeight, 5 * scale);
      drawBox(ctx, rightX, submissionY, boxWidth, submissionHeight, 5 * scale);
    }
    const boxPadding = mm(4);
    const leftInnerX = leftX + boxPadding;
    const rightInnerX = rightX + boxPadding;
    const innerWidth = boxWidth - boxPadding * 2;
    const headingY = submissionY + mm(10);
    const dividerY = submissionY + mm(13.5);
    const lineY = submissionY + mm(19);
    ctx.font = fontStyle(15, 700);
    ctx.textAlign = "left";
    ctx.fillText("Submitted By", leftInnerX, headingY);
    ctx.fillText("Submitted To", rightInnerX, headingY);
    if (showBoxOutlines) {
      ctx.strokeStyle = "#777";
      ctx.lineWidth = scale;
      [leftInnerX, rightInnerX].forEach((x) => {
        ctx.beginPath();
        ctx.moveTo(x, dividerY);
        ctx.lineTo(x + innerWidth, dividerY);
        ctx.stroke();
      });
    }
    ctx.strokeStyle = "#141414";
    ctx.lineWidth = 1.2 * scale;

    const studentLabelWidth = mm(16);
    const drawStudentRow = (label, value, y) => {
      ctx.font = fontStyle(12, 700);
      ctx.textAlign = "left";
      ctx.fillText(label, leftInnerX, y);
      paperText(
        value,
        leftInnerX + studentLabelWidth,
        y,
        innerWidth - studentLabelWidth,
        12,
        400,
        15,
      );
    };
    drawStudentRow("Name:", getValue("studentName"), lineY);
    drawStudentRow("ID:", getValue("studentId"), lineY + mm(8));
    drawStudentRow("Session:", getValue("studentSession"), lineY + mm(16));
    let studentY = lineY + mm(25);
    studentY +=
      paperText(
        getValue("studentDepartment"),
        leftInnerX,
        studentY,
        innerWidth,
        12,
        400,
        15,
      ) *
      15 *
      scale;
    paperText(
      getValue("studentUniversity"),
      leftInnerX,
      studentY + mm(1.5),
      innerWidth,
      12,
      400,
      15,
    );

    let teacherY = lineY;
    [...teachersList.children].forEach((card) => {
      const name = card.querySelector('[name^="teacherName"]').value.trim();
      const designation = card
        .querySelector('[name^="teacherDesignation"]')
        .value.trim();
      if (name) {
        teacherY +=
          paperText(name, rightInnerX, teacherY, innerWidth, 12, 600, 15) *
          15 *
          scale;
      }
      if (designation) {
        teacherY += mm(1);
        teacherY +=
          paperText(
            designation,
            rightInnerX + mm(2),
            teacherY,
            innerWidth - mm(2),
            12,
            400,
            15,
          ) *
          15 *
          scale;
        teacherY += mm(1.5);
      }
    });
    teacherY += mm(1);
    teacherY +=
      paperText(
        getValue("teacherDepartment"),
        rightInnerX,
        teacherY,
        innerWidth,
        12,
        400,
        15,
      ) *
      15 *
      scale;
    paperText(
      getValue("teacherUniversity"),
      rightInnerX,
      teacherY + mm(1.5),
      innerWidth,
      12,
      400,
      15,
    );
    if (includeDate) {
      if (showBoxOutlines)
        drawBox(
          ctx,
          contentX,
          dateBoxY,
          contentWidth,
          dateBoxHeight,
          5 * scale,
        );
      paperText(
        `Submission Date: ${formatSubmissionDate(getValue("submissionDate"))}`,
        centerX,
        dateBoxY + mm(8.5),
        contentWidth - mm(12),
        12,
        400,
        15,
        "center",
      );
    }
    return canvas;
  }

  async function loadExportLogo() {
    const image = preview.querySelector(".university-logo");
    if (!image.complete) {
      await new Promise((resolve, reject) => {
        image.addEventListener("load", resolve, { once: true });
        image.addEventListener(
          "error",
          () => reject(new Error("The university logo could not be loaded.")),
          { once: true },
        );
      });
    }
    if (!image.naturalWidth || !image.naturalHeight) {
      throw new Error(
        "The university logo is unavailable. Reload the page and try again.",
      );
    }
    return image;
  }

  function canvasBlob(canvas, type, quality) {
    return new Promise((resolve, reject) => {
      if (typeof canvas.toBlob === "function") {
        canvas.toBlob(
          (blob) => {
            if (blob) resolve(blob);
            else
              reject(
                new Error("Your browser could not encode the cover page."),
              );
          },
          type,
          quality,
        );
        return;
      }
      try {
        const dataUrl = canvas.toDataURL(type, quality);
        const [header, encoded] = dataUrl.split(",");
        if (!header || !encoded) throw new Error("The image data was empty.");
        const binary = atob(encoded);
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index++)
          bytes[index] = binary.charCodeAt(index);
        resolve(new Blob([bytes], { type }));
      } catch (error) {
        reject(
          new Error(
            `Your browser could not encode the cover page: ${error.message}`,
          ),
        );
      }
    });
  }

  function downloadBlob(blob, extension) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = safeFilename(extension);
    link.style.display = "none";
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    return safeFilename(extension);
  }

  async function createPdfBlob(canvas) {
    const jpeg = await canvasBlob(canvas, "image/jpeg", 0.94);
    const imageBytes = new Uint8Array(await jpeg.arrayBuffer());
    const encoder = new TextEncoder();
    const header = encoder.encode("%PDF-1.4\n");
    const objects = [];
    objects.push(
      encoder.encode("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"),
    );
    objects.push(
      encoder.encode(
        "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
      ),
    );
    objects.push(
      encoder.encode(
        "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] " +
          "/Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>\nendobj\n",
      ),
    );
    const content = encoder.encode("q\n595.28 0 0 841.89 0 0 cm\n/Im0 Do\nQ\n");
    objects.push(
      concatBytes(
        encoder.encode(`4 0 obj\n<< /Length ${content.length} >>\nstream\n`),
        content,
        encoder.encode("endstream\nendobj\n"),
      ),
    );
    objects.push(
      concatBytes(
        encoder.encode(
          `5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${canvas.width} /Height ${canvas.height} ` +
            `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${imageBytes.length} >>\nstream\n`,
        ),
        imageBytes,
        encoder.encode("\nendstream\nendobj\n"),
      ),
    );
    let offset = header.length;
    const offsets = [0];
    for (const object of objects) {
      offsets.push(offset);
      offset += object.length;
    }
    const xrefOffset = offset;
    const xref = encoder.encode(
      `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n` +
        offsets
          .slice(1)
          .map((item) => `${String(item).padStart(10, "0")} 00000 n \n`)
          .join("") +
        `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`,
    );
    return new Blob([header, ...objects, xref], { type: "application/pdf" });
  }

  function concatBytes(...parts) {
    const length = parts.reduce((total, part) => total + part.length, 0);
    const output = new Uint8Array(length);
    let offset = 0;
    parts.forEach((part) => {
      output.set(part, offset);
      offset += part.length;
    });
    return output;
  }

  async function exportPdf() {
    try {
      const logo = await loadExportLogo();
      const canvas = makeExportCanvas(logo);
      const blob = await createPdfBlob(canvas);
      const filename = downloadBlob(blob, "pdf");
      logAction(`Downloaded A4 PDF (${filename})`);
      showToast("Your A4 PDF has been downloaded.");
    } catch (error) {
      console.error("PDF export failed:", error);
      showToast(`PDF export failed: ${error.message}`);
    }
  }

  document.querySelectorAll("[data-dialog]").forEach((button) => {
    button.addEventListener("click", () => {
      menu.open = false;
      const dialog = document.getElementById(button.dataset.dialog);
      logAction(`Opened ${button.textContent.trim()}`);
      if (dialog.id === "activity-dialog") renderActivity();
      dialog.showModal();
    });
  });
  document.querySelectorAll("[data-theme]").forEach((button) => {
    button.addEventListener("click", () => {
      applyTheme(button.dataset.theme);
      logAction(`Changed app theme to ${themeColors[currentTheme]}`);
      document.querySelector("#theme-dialog").close();
    });
  });
  document.querySelectorAll("[data-font]").forEach((button) => {
    button.addEventListener("click", () => {
      currentFont = button.dataset.font;
      document.documentElement.style.setProperty(
        "--paper-font",
        fontStack(currentFont),
      );
      renderFontSelection();
      logAction(`Changed cover page font to ${currentFont}`);
      document.querySelector("#font-dialog").close();
    });
  });
  document
    .querySelector("#activity-dialog")
    .addEventListener("close", renderActivity);

  function renderActivity() {
    const list = document.querySelector("#activity-list");
    list.replaceChildren();
    if (!activity.length) {
      const item = document.createElement("li");
      item.textContent = "No activity yet.";
      list.append(item);
      return;
    }
    activity.forEach(({ message, time }) => {
      const item = document.createElement("li");
      item.append(document.createTextNode(message));
      const timestamp = document.createElement("time");
      timestamp.dateTime = time.toISOString();
      timestamp.textContent = time.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
      item.append(timestamp);
      list.append(item);
    });
  }

  form.addEventListener("input", render);
  includeDateToggle.addEventListener("change", () => {
    if (includeDateToggle.checked && !submissionDateInput.value)
      submissionDateInput.value = currentDateValue();
    render();
  });
  showBoxOutlinesToggle.addEventListener("change", render);
  document
    .querySelector("#add-teacher")
    .addEventListener("click", () => addTeacher());
  document
    .querySelector("#clear-designations")
    .addEventListener("click", () => {
      [...teachersList.children].forEach((card) => {
        card.querySelector('[name^="teacherDesignation"]').value = "";
      });
      logAction("Cleared teacher designations");
      render();
      showToast("Teacher designations cleared.");
    });
  document.querySelector("#sample-button").addEventListener("click", () => {
    menu.open = false;
    fillSampleData();
  });
  document.querySelector("#clear-button").addEventListener("click", () => {
    menu.open = false;
    clearForm();
  });
  document.querySelector("#export-pdf").addEventListener("click", exportPdf);
  document
    .querySelector("#export-pdf-secondary")
    .addEventListener("click", exportPdf);
  document.querySelectorAll("dialog").forEach((dialog) => {
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) dialog.close();
    });
  });

  getField("documentType").value = "Assignment/Lab-Report";
  getField("studentUniversity").value = university;
  getField("teacherUniversity").value = university;
  addTeacher("Course Instructor", "Course Instructor Designation");
  render();
  renderActivity();
  logAction("App initialized");
  updateUsageCount();
})();
